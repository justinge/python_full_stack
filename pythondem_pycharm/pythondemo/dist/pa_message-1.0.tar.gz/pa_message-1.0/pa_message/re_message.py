def receive():
    return "10086短信"